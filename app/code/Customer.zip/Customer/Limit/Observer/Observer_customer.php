<?php
class Observer_customer
    private $_helper;
    public function __construct()
    {
        $this->_helper = Mage::helper('sales_quote_save_before');
    }
    /**
     * No single order can be placed over the amount of X
     */
    public function enforceSingleOrderLimit($observer)
    {
        if (!$this->_helper->isModuleEnabled()) {
            return;
        }

        //todo - look up customer info and check if they already purchase this item
        $quote = $observer->getEvent()->getQuote();
        if ($quote->getCart()->getItemsCount() == 1) {

            Mage::getSingleton('checkout/session')->addError('limit only one product per order');
            Mage::app()->getFrontController()->getResponse()->setRedirect(Mage::getUrl('checkout/cart'));
            Mage::app()->getResponse()->sendResponse();
            exit;
        }
    }
}