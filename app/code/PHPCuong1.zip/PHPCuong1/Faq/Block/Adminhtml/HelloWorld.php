<?php
namespace PHPCuong\Faq\Block\Adminhtml\s;
class HelloWorld extends \Magento\Framework\View\Element\Template
{
    protected $_request;    
    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\App\Request\Http $request,
        array $data = []
    )
    {        
        $this->_request = $request;
        parent::__construct($context, $data);
    }
    
    public function getControllerModule()
    {
        return $this->_request->getControllerModule();
    }
    
    public function getFullActionName()
    {
        return $this->_request->getFullActionName();
    }
    
    public function getRouteName()
    {
        return $this->_request->getRouteName();
    }
    
    public function getActionName()
    {
        return $this->_request->getActionName();
    }
    
    public function getControllerName()
    {
        return $this->_request->getControllerName();
    }
    
    public function getModuleName()
    {
        return $this->_request->getModuleName();
    }
}
?>