# magento2-custom-tab-customer
How to add a new custom tab to the customer account in both backend and frontend Magento 2.

# See the video about this best practice here
https://www.youtube.com/watch?v=tI6TUnWK3EA
