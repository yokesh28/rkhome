<?php



namespace send\sms\Block;

class sendsms extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * @var int
     */
    protected $oderId;
    

    /**
     * @var array
     */
    protected $lastOrder;
    
    protected $orderPrice;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Checkout\Model\Session $checkoutSession,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->checkoutSession = $checkoutSession;
    }

    protected function _prepareLayout()
    {
        $lastOrder = $this->checkoutSession->getLastRealOrder();
        $this->orderId = $lastOrder->getIncrementId();
        $this->lastOrder = $lastOrder->getData();
        return parent::_prepareLayout();
    }
    
    public function getOrderId()
    {
        return $this->orderId; 
    }
    public function getLastOrder()
    {
        return $this->lastOrder;
    }
    
  public function getOrderDetails($incrementId)
{
    $orderDetail = $this->order->loadByIncrementId($incrementId);
    return $orderDetail;
}
  

public function categorymsg(){

    $orderId = $this->getOrderId();


$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
$order = $objectManager->create('Magento\Sales\Model\Order')->loadByIncrementId($orderId);

$items = $order->getAllVisibleItems();

foreach($items as $i):
    $_product = $objectManager->create('Magento\Catalog\Model\Product')->load($i->getProductId());
    $categoryIds = $_product->getCategoryIds();

endforeach;


if (in_array(51, $categoryIds))
  {

  echo "Found schemes";
  }
  else
  {
  echo "Schemes Not Found ";
  }

  }
    
    
 
 
 
 


   
     
}
