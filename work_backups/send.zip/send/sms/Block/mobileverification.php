<?php

namespace send\sms\Block;

ini_set('display_errors', 1);

class mobileverification extends \Magento\Framework\View\Element\Template
{

public function checknumber(){

	 $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()
->get('Magento\Framework\App\ResourceConnection');	

$connection= $this->_resources->getConnection();
$tableName = $this->_resources->getTableName('otpp');

$dates = date("Y-m-d");

$phone = $_POST["phone"];

// SELECT DATA
$sql = "SELECT otp FROM otpp WHERE `phone`='$phone' AND `dates`='$dates'";
$result = $connection->fetchall($sql); 


if(!empty($result)){ 
// if already exists
$code = $result;
$code = $result[0];
$otppass = $code['otp'];

echo "Your number already exists";


}else{  
// if already not exists 
    
$randcode = rand(100000, 999999);

$sendotp = $randcode;

$sql = "INSERT INTO " . $tableName . "(phone, otp, dates) VALUES ('$phone', '$sendotp', '$dates')";

echo "new num" . $sendotp;



}
$connection->query($sql);

}


public function checkotp(){

$this->_resources = \Magento\Framework\App\ObjectManager::getInstance()
->get('Magento\Framework\App\ResourceConnection');	

$connection= $this->_resources->getConnection();
$tableName = $this->_resources->getTableName('otpp');

$dates = date("Y-m-d");

$ckotp = $_POST["getotp"];

// SELECT DATA
$sql = "SELECT otp FROM otpp WHERE `otp`='$ckotp' AND `dates`='$dates'";
$result = $connection->fetchall($sql); 


if(!empty($result)){ 
// if already exists
$code = $result;
$code = $result[0];
$otppass = $code['otp'];

 echo $otppass;

}



}

}



